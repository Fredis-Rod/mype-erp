# Handoff: Mini ERP — Sistema de Gestión para Pequeños Negocios

## Overview

Diseño de interfaz completo para un mini ERP dirigido a micro y pequeñas empresas. El sistema cubre Ventas, Inventario, Compras y Finanzas — módulos esenciales para emprendedores y personal administrativo. El diseño enfatiza claridad visual, acceso rápido a datos clave y usabilidad sin fricciones.

## About the Design Files

Los archivos en este paquete son **prototipos HTML de alta fidelidad** creados como referencias de diseño. **No son código de producción.** El objetivo es que recrees estas vistas en tu codebase existente (React, Vue, backend con templates, etc.) usando los patrones y librerías establecidos en tu proyecto. Si no existe un entorno definido, elige el framework más apropiado para la empresa/proyecto y implementa el diseño ahí.

## Fidelity

**High-fidelity (hifi)** — Mockups pixel-perfectos con colores finales, tipografía, espaciado e interacciones definidas. Recrea la UI pixel-perfectamente usando las librerías y patrones de tu codebase.

## Paleta de Colores

| Elemento | Hex | Uso |
|----------|-----|-----|
| Verde principal | #10b981 | Marca, botones primarios, estados positivos (pagado, disponible) |
| Verde claro | #0f9169 | Variante más oscura para énfasis |
| Verde muy claro | #e7f7f0 | Fondo para elementos verdes (KPIs, badges) |
| Verde sidebar | #f1f6f2 | Fondo del sidebar |
| Azul acento | #2f6fed | Botones secundarios, KPIs pendientes, contrastes |
| Azul claro | #e8eefd | Fondo para elementos azules |
| Gris oscuro texto | #1f2e27 | Texto principal, títulos |
| Gris medio | #4c5a52 | Texto secundario |
| Gris claro | #7c8b83 | Etiquetas, placeholders |
| Gris muy claro | #9fada6 | Texto débil, leyendas |
| Rojo alerta | #c0392b | Solo para estados críticos (stock bajo, agotado) |
| Rojo muy claro | #fdeeee | Fondo para alertas rojas |
| Amarillo alerta | #b7791f | Estado "Pendiente" (compras) |
| Amarillo muy claro | #fef6e6 | Fondo para estados amarillos |
| Blanco | #fff | Fondos de cards y contenedores |
| Fondo página | #f9faf8 | Fondo general de la app |
| Bordes | #edf2ee | Divisores y bordes sutiles |

## Tipografía

- **Familia**: System fonts (-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif)
- **Títulos principales**: 18px, 700 weight
- **Subtítulos**: 13.5px, 600 weight
- **Texto body**: 13px, 400 weight
- **Labels**: 12.5px, 500-600 weight
- **Small text**: 11.5px, 400-600 weight

## Espaciado

- **Padding contenedor**: 24px (interior de pantallas)
- **Padding card**: 16–18px
- **Gap entre elementos**: 14–20px (según agrupación)
- **Altura header**: 64px
- **Ancho sidebar**: 232px
- **Alto pantalla**: 800px (todas las vistas)

## Pantallas

### 01 — Login

**Propósito**: Autenticación segura con marca y confianza.

**Layout**:
- Split 50/50: izquierda verde oscuro (#0f9169) con marca y mensaje; derecha blanca con formulario
- Izquierda: logo (M en cuadrado), tagline, copyright
- Derecha: form centrado 360px de ancho

**Componentes**:
- Email input: border 1px #dde6e0, padding 11px 14px, border-radius 9px
- Password input: igual
- Checkbox "Recordarme"
- Link "¿Olvidaste tu contraseña?" en color #0f9169
- Botón primario: verde #10b981, shadow 0 4px 12px rgba(16,185,129,.3), border-radius 9px, padding 12px, font 14px 700
- Link de registro: color #0f9169

### 02 — Dashboard

**Propósito**: Vista general en tiempo real de ventas, ingresos y alertas críticas.

**Layout**:
- Sidebar fijo 232px a la izquierda
- Header 64px: barra de búsqueda 190px, notificaciones (con dot azul #2f6fed), botón "Nueva venta" azul, avatar
- Contenido principal en grid vertical

**Componentes principales**:

**KPI Cards** (4x1 grid):
- Ventas de hoy: $4,280 (verde)
- Ingresos del mes: $68,450 (verde)
- Órdenes pendientes: 12 (azul)
- Stock bajo: 5 (rojo)

Cada card: 
- background #fff, border 1px #edf2ee, padding 16px 18px, border-radius 12px
- Icono 28x28, color de tema, fondo pastel
- Valor: 24px 700 color #1f2e27
- Cambio: 12px color de tema, 600 weight

**Gráfico de barras** (últimos 7 días):
- 7 barras, gap 14px, altura variable
- Barra destacada (jueves): #2f6fed
- Barras normales: #e7f7f0
- Labels: 10.5px color #9fada6

**Stock bajo** (card derecha):
- 3 items: Producto D (3 uds, 15% barra), E (5 uds, 25%), F (2 uds, 10%)
- Barra roja #c0392b

**Ventas recientes** (tabla fondo):
- 3 filas: Cliente, Producto, Monto, Estado
- Estados: badges con colores (Pagado verde, Pendiente azul)

### 03 — Punto de Venta

**Propósito**: Interfaz rápida para registrar ventas en tienda.

**Layout**:
- Sidebar izquierda (igual a Dashboard)
- Header (igual)
- Contenido: izquierda catálogo de productos, derecha carrito ("Venta actual")

**Catálogo** (izquierda):
- Tabs: Todos (activo verde), Abarrotes, Bebidas, Limpieza, Otros
- Grid 4 columnas de cards:
  - Imagen placeholder 76px alto, border-radius 8px, bg #eef4f0
  - Nombre: 13px 600
  - Precio: 13.5px 700 verde
  - Stock: 11px gris
  - 1 card destacada: border 2px #10b981

**Carrito** (derecha, 360px ancho):
- "Venta actual" header
- Cliente selector
- Líneas de items: cantidad × precio = total
- Línea gris separador
- Subtotal, Impuesto (16%), Total
- Botón "Cobrar $XXX": verde grande, shadow

### 04 — Reportes

**Propósito**: Análisis de ventas, márgenes y productos top.

**Layout**: 
- Mismo sidebar + header, con dropdown "Últimos 30 días"

**KPI Row** (4 cards):
- Ventas totales: $68,450 (verde +8%)
- Ticket promedio: $284 (verde +3%)
- Órdenes totales: 241 (azul, 12 pendientes)
- Margen bruto: 34% (rojo -1.5%)

**Gráfico ingresos por semana** (izquierda):
- 4 semanas, barras variable altura
- Semana 4 destacada: #10b981

**Gráfico pie ventas por categoría** (derecha):
- Abarrotes 45% verde, Bebidas 27% azul, Otros 28% gris
- Leyenda con dots de color

**Tabla productos más vendidos** (fondo):
- Columnas: Producto, Unidades, Ingresos, Margen
- 3 rows ejemplo
- Márgenes en verde

### 05 — Inventario

**Propósito**: Control de stock y gestión de productos.

**Layout**: 
- Sidebar + header con búsqueda y botón "Nuevo producto" azul

**KPI Row** (4 cards):
- Total de productos: 86
- Valor de inventario: $41,280
- Stock bajo: 5 (rojo)
- Categorías: 6

**Tabla productos** (flex 1, scrollable):
- Columnas: Producto, Categoría, Stock, Precio, Estado
- Estados: Disponible (verde), Stock bajo (rojo), Agotado (gris)
- 6 rows ejemplo con distribucion realista

### 06 — Compras a Proveedores

**Propósito**: Gestión de órdenes de compra y proveedores.

**Layout**: 
- Sidebar + header con botón "Nueva orden de compra" azul

**KPI Row** (4 cards):
- Órdenes activas: 8
- Gasto del mes: $22,340
- Proveedores: 14
- Por recibir: 3 (azul)

**Tabla órdenes de compra** (flex 1):
- Columnas: Proveedor, Fecha, Monto, Estado
- Estados: Recibido (verde), En tránsito (azul), Pendiente (amarillo)
- 4 rows ejemplo

### 07 — Finanzas

**Propósito**: Resumen de ingresos, gastos y flujo de caja.

**Layout**: 
- Sidebar + header con dropdown "Este mes"

**KPI Row** (4 cards):
- Ingresos: $68,450 (verde +8%)
- Gastos: $41,120 (azul +4%)
- Utilidad neta: $27,330 (verde +14%)
- Flujo de caja: $15,900 (gris, disponible hoy)

**Gráfico ingresos vs. gastos** (últimos 4 meses):
- 4 grupos de 2 barras (ingresos verde, gastos azul)
- Altura variable
- Meses: Abr, May, Jun, Jul
- Leyenda con dots de color

**Tabla movimientos recientes** (flex 1):
- Columnas: Concepto, Tipo (Ingreso/Gasto), Monto, Fecha
- 3 rows ejemplo
- Ingresos en verde, gastos en azul

## Interacciones

- **Sidebar**: Todos los items son clickeables (navegación)
- **Botones primarios** (verde): Acción principal (Nueva venta, Nuevo producto, etc.)
- **Botones secundarios** (azul): Acciones alternativas
- **Tabs**: Click para filtrar/cambiar vista (Punto de venta, Categorías)
- **Search**: Input funcional (no implementado en HTML)
- **Notificaciones**: Dot rojo #2f6fed en campana indica nuevas notificaciones
- **Estados en tablas**: Badges de color — no editables en esta maqueta

## Responsive

Este diseño está pensado para **desktop/laptop** (viewport mínimo ~1280px). Los elementos están en unidades fijas (px). Para mobile/tablet, considera:
- Sidebar colapsable
- Grid de cards a 2 columnas (tablet) o 1 (mobile)
- Tablas convertidas a cards horizontales
- Header adaptado

## Assets

No hay imágenes custom. Placeholders:
- Avatares: círculos de color (background #10b981, iniciales en blanco)
- Imágenes de producto: rectángulos grises #eef4f0 de 76px × 76px
- Iconos: SVG inline (Feather icons style, 18px)

## State Management

**Sidebar activo**: Qué módulo está seleccionado (controla highlight)
**Filtros por rango**: Dashboard, Reportes y Finanzas usan "últimos X días/mes"
**Búsqueda**: En Inventario y Punto de venta
**Carrito (PdV)**: Items con cantidad, cálculo de total
**Tabla sorting**: Opcional — columnas podrían ser ordenables

## Files

El paquete incluye:
- `ERP - Diseño Visual.dc.html` — Todas las 7 pantallas en un solo archivo HTML

Cada pantalla está envuelta en un `<div class="scr-card">` con `data-screen-label` (01–07) para identificarlas.

## Developer Notes

- El HTML es un prototipo estático — no hay backend conectado
- Todos los datos (números, tablas, gráficos) son hardcoded como ejemplos
- Los gráficos de barras y pie son CSS puro (divs coloreados), no canvas/SVG — considera Chart.js, Recharts o similar en producción
- Las tablas usan CSS Grid — considera un componente de tabla reutilizable
- No hay validación de formularios en el Login
- El carrito (PdV) es estático — implementar con estado real (array de items, total dinámico)

